# 🏋️ CleanPro - AI-Powered Fitness Assistant

<div align="center">

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Node](https://img.shields.io/badge/node-%3E%3D20.0.0-brightgreen.svg)
![React](https://img.shields.io/badge/react-19.2.0-blue.svg)

**Train Smarter, Not Harder** - Your intelligent fitness companion powered by AI

</div>

---

## 📖 About

CleanPro is a modern, AI-powered fitness application designed to help users achieve their fitness goals through personalized workout plans, intelligent diet tracking, and comprehensive progress analytics. The application provides customized 7-day workout routines for both weight loss and muscle gain goals, with detailed exercise instructions, durations, and calorie estimates. Users can track their daily meals using the Smart Dietician feature, which includes a database of 20+ common foods and allows custom meal entries with automatic calorie calculations. The Workout Detection feature calculates calories burned based on exercise type, duration, and user weight using the MET (Metabolic Equivalent) formula. The Performance Analytics section provides AI-powered progress assessment, showing overall status (Good/Average/Bad) based on workout frequency, nutrition tracking, and consistency patterns. All user data including profile information, workout history, and meal plans are stored locally using browser localStorage for privacy and security.

---

## ✨ Features

**Workout Detection:** Calculate calories burned for 12+ exercise types including Running, Cycling, Swimming, Weightlifting, HIIT, Yoga, and more. Simply select your exercise type, enter duration in minutes and your weight in kg, and get instant calorie calculations using the scientifically-proven MET formula. All workouts are automatically saved to your history for progress tracking.

**Smart Dietician:** Input meals and get instant total calorie counts for your entire meal plan. Choose from a pre-loaded database of 20+ common foods with accurate calorie information, or add custom foods with manual calorie entry. Build complete meal plans by adding multiple items, view total calories, and save your meal plans for future reference. Track your daily calorie intake to stay on target with your fitness goals.

**Performance Analytics:** Get comprehensive insights into your fitness journey with AI-powered progress analysis. The system evaluates your workout frequency over the last 7 days, nutrition tracking consistency, and overall activity patterns to provide an overall progress status of Good, Average, or Bad. View detailed statistics including total workouts completed, total calories burned, and current workout streak. The analytics automatically update based on your workout and meal history stored in localStorage.

**Personalized Workout Plans:** Access complete 7-day workout routines tailored to your fitness goal. Weight Loss plans focus on cardio, HIIT, and fat-burning exercises with calorie estimates ranging from 200-600 kcal per session. Muscle Gain plans emphasize strength training with compound lifts, targeting 300-450 kcal per session. Each day includes specific exercises with durations, sets, reps, and focus areas clearly outlined.

**Diet Plans:** Receive daily meal plans aligned with your fitness goals. Weight Loss diets provide calorie-controlled meals (1600-1900 kcal/day) with balanced macros, while Muscle Gain diets offer high-protein meal plans (3000-3500 kcal/day) to support muscle growth. Each day includes breakfast, lunch, dinner, snacks, and detailed macro breakdowns (Protein, Carbs, Fats).

**Profile Management:** Manage your personal information including name, email, date of birth, and profile photo. Upload photos from your device or camera, with options to delete or change your profile picture. View dynamic fitness statistics that automatically calculate based on your workout and meal history, including workouts completed, total calories burned, current streak, and fitness goal.

**Modern UI/UX:** Experience a beautiful, modern interface with gradient designs, smooth animations powered by Framer Motion, and fully responsive layout that works seamlessly on desktop, tablet, and mobile devices. The application features intuitive navigation, accessible components built with Radix UI, and a clean design that makes fitness tracking enjoyable and engaging.

---

## 🛠️ Tech Stack

**Frontend:** The application is built with React 19.2.0 and TypeScript 5.6.3 for type-safe, modern web development. Vite 7.1.9 serves as the build tool and development server, providing fast hot module replacement and optimized production builds. Routing is handled by Wouter 3.3.5, a lightweight alternative to React Router. Animations and transitions are powered by Framer Motion 12.23.24, creating smooth, professional user interactions. Styling is done with Tailwind CSS 4.1.14 for utility-first, responsive design. UI components are built on Radix UI primitives for accessibility and customization, while Lucide React provides a comprehensive icon library.

**Backend:** The server-side is built with Express 4.21.2 framework and TypeScript for type safety. Database operations use Drizzle ORM 0.39.1, which supports PostgreSQL for optional full-stack features. The backend can be run independently or alongside the frontend for complete application functionality.

**Development Tools:** ESBuild provides fast bundling and compilation, while TSX enables direct TypeScript execution during development. Drizzle Kit handles database migrations and schema management. The project uses modern development practices with hot reloading, TypeScript type checking, and optimized build processes.

---

## 📋 Prerequisites

Before installing CleanPro, ensure you have Node.js version 20.0.0 or higher installed on your system, which includes npm package manager. You can download Node.js from the official website at nodejs.org. Git is required for cloning the repository, available at git-scm.com. PostgreSQL is optional and only needed if you plan to use full-stack features with database support; you can download it from postgresql.org or use cloud services like Neon or Supabase.

---

## 🚀 Installation

**Clone the Repository:** Start by cloning the CleanPro repository to your local machine using `git clone https://github.com/yourusername/CleanPro.git`, then navigate into the project directory with `cd CleanPro`.

**Install Dependencies:** Run `npm install` in the project root directory to install all required dependencies. This process typically takes 2-5 minutes depending on your internet connection. The installation will create a `node_modules` folder containing all project dependencies.

**Environment Setup (Optional):** For full-stack features with database support, create a `.env` file in the root directory and add your PostgreSQL connection string as `DATABASE_URL=postgresql://username:password@localhost:5432/cleanpro`. If you only want to run the frontend, you can skip this step entirely.

**Windows PowerShell Note:** If you encounter execution policy errors on Windows, either switch to Command Prompt in your terminal or run `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser` in PowerShell as Administrator.

---

## 💻 Usage

**Development Mode - Frontend Only:** Run `npm run dev:client` to start the Vite development server. This will launch the application on `http://localhost:5000` with hot module replacement, meaning changes to your code will automatically refresh in the browser. This is the quickest way to get started and doesn't require database setup.

**Development Mode - Full Stack:** For Windows users, run `$env:NODE_ENV="development"; npm run dev` in PowerShell, or use `npm run dev` directly on Linux/Mac. This starts both the frontend and backend servers together, enabling full application functionality with database support.

**Production Build:** To create an optimized production build, run `npm run build` which compiles and bundles all assets. Then start the production server with `npm start`. The production build is optimized for performance with minified code and optimized assets.

**Other Commands:** Use `npm run check` to perform TypeScript type checking and identify any type errors in your code. Run `npm run db:push` to push database schema changes when using Drizzle ORM with PostgreSQL.

---

## 📁 Project Structure

The project follows a clean, organized structure with clear separation of concerns. The `client/` directory contains all frontend React code, including `src/components/` for reusable UI components, `src/pages/` for page-level components (home, dashboard, profile, workout-detection, smart-dietician), `src/lib/` for utilities and data files, and `src/hooks/` for custom React hooks. The `server/` directory houses the Express backend with routes, static file serving, and storage utilities. The `shared/` folder contains TypeScript types and schemas shared between frontend and backend. The `attached_assets/` directory stores images and other static assets. Configuration files like `package.json`, `tsconfig.json`, and `vite.config.ts` are in the root directory, along with build scripts in the `script/` folder.

---

## 🎯 Key Features Explained

**Workout Plans:** The application provides two types of 7-day workout plans. Weight Loss plans focus on high-intensity cardio, HIIT sessions, and fat-burning exercises, with each day including specific exercises, durations, sets, reps, and estimated calories burned (typically 200-600 kcal per session). Muscle Gain plans emphasize strength training with compound movements, targeting different muscle groups each day, with calorie estimates of 300-450 kcal per session. Each exercise includes detailed instructions and timing information.

**Diet Plans:** Daily meal plans are tailored to fitness goals. Weight Loss diets provide calorie-controlled meals ranging from 1600-1900 kcal per day, with balanced macronutrients to support fat loss while maintaining energy levels. Muscle Gain diets offer high-protein meal plans with 3000-3500 kcal per day, designed to support muscle growth and recovery. Each day includes complete meal breakdowns for breakfast, lunch, dinner, and snacks, along with detailed macro information (Protein, Carbs, Fats).

**Progress Tracking:** The application automatically tracks and calculates various fitness metrics. Total workouts completed shows the cumulative number of completed workout sessions. Total calories burned aggregates all calories from completed workouts. Current streak tracks consecutive days with completed workouts. Overall progress status uses AI analysis to evaluate workout frequency, nutrition tracking consistency, and activity patterns, providing a Good, Average, or Bad assessment with personalized feedback messages.

---

## 🔧 Troubleshooting

**PowerShell Execution Policy Error (Windows):** If you see "running scripts is disabled" error, switch your VS Code terminal to Command Prompt instead of PowerShell, or run `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser` in PowerShell as Administrator to permanently fix the issue.

**Port 5000 Already in Use:** On Windows, use `netstat -ano | findstr :5000` to find the process using port 5000, then `taskkill /PID <PID> /F` to kill it. On Linux/Mac, use `lsof -ti:5000 | xargs kill -9`. Alternatively, modify the port in `package.json` scripts to use a different port like 3000.

**Module Not Found Errors:** Delete the `node_modules` folder and `package-lock.json` file, then run `npm install` again. This will reinstall all dependencies fresh and resolve most module-related issues.

**TypeScript Errors:** Run `npm run check` to see detailed TypeScript error messages. Ensure all dependencies are properly installed and your TypeScript version matches the project requirements.

---

## 🤝 Contributing

Contributions to CleanPro are welcome and appreciated. To contribute, fork the repository and create a feature branch using `git checkout -b feature/AmazingFeature`. Make your changes following the existing code style, add comments for complex logic, and update documentation as needed. Test your changes thoroughly before committing. Commit with a descriptive message like `git commit -m 'Add some AmazingFeature'`, then push to your branch with `git push origin feature/AmazingFeature` and open a Pull Request. Please ensure your code follows the project's coding standards and includes appropriate documentation.

---

## 📝 License

This project is licensed under the MIT License, which allows free use, modification, and distribution of the code. See the LICENSE file in the repository root for full license details.

---

## 👨‍💻 Author

**Your Name** - GitHub: [@yourusername](https://github.com/yourusername) - Email: your.email@example.com

---

## 🙏 Acknowledgments

CleanPro uses several excellent open-source libraries and tools. Radix UI provides accessible, unstyled component primitives that form the foundation of our UI components. Lucide offers a beautiful, consistent icon library. Framer Motion enables smooth, professional animations throughout the application. Tailwind CSS provides utility-first CSS for rapid, responsive design. We're grateful to all the maintainers and contributors of these projects.

---

## 📊 Project Status

**Current Version:** 1.0.0  
**Status:** ✅ Active Development

The project is actively maintained and in active development. New features and improvements are regularly added based on user feedback and requirements.

---

## 🗺️ Roadmap

Future enhancements planned for CleanPro include real-time AI form correction using computer vision to analyze exercise form and provide feedback. Integration with fitness wearables will allow automatic workout and activity tracking. Social features and community challenges will enable users to connect, compete, and motivate each other. Advanced meal planning with recipe suggestions will help users discover new healthy meals. A mobile app built with React Native will provide native mobile experience. Multi-language support will make the application accessible to users worldwide.

---

## 📞 Support

If you encounter any issues, have questions, or need help with CleanPro, please check the Issues page on GitHub to see if your problem has already been addressed. If not, create a new issue with a detailed description of your problem, including steps to reproduce, expected behavior, and actual behavior. For direct contact, reach out to the maintainer via the email provided in the Author section.

---

<div align="center">

**Made with ❤️ for fitness enthusiasts**

⭐ Star this repo if you find it helpful!

</div>
