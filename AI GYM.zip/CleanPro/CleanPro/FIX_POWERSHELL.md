# 🔧 Fix PowerShell Execution Policy Error

## Problem
You're seeing this error:
```
npm : File C:\Program Files\nodejs\npm.ps1 cannot be loaded because running scripts is disabled on this system.
```

This is a Windows security feature that blocks scripts from running.

---

## ✅ Solution Options (Choose One)

### **Option 1: Change Execution Policy (Recommended for Development)**

1. **Open PowerShell as Administrator:**
   - Press `Windows Key`
   - Type: `PowerShell`
   - Right-click on "Windows PowerShell"
   - Select "Run as Administrator"
   - Click "Yes" when prompted

2. **Run this command:**
   ```powershell
   Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```

3. **Press Enter** and type `Y` when asked to confirm

4. **Close the Administrator PowerShell**

5. **Go back to VS Code terminal** and try `npm install` again

---

### **Option 2: Use Command Prompt Instead (Easiest)**

1. **In VS Code, change terminal to Command Prompt:**
   - Click the dropdown next to the `+` in the terminal panel
   - Select "Command Prompt" (or "cmd")
   - Or press `Ctrl + Shift + P` → Type "Terminal: Select Default Profile" → Choose "Command Prompt"

2. **Now run:**
   ```cmd
   npm install
   ```

This will work immediately without changing any settings!

---

### **Option 3: Bypass for Current Session Only**

In your VS Code terminal (PowerShell), run:
```powershell
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
```

Then run `npm install` immediately.

**Note:** This only works for the current terminal session. You'll need to do it again if you close VS Code.

---

## 🎯 Recommended: Use Command Prompt

**Easiest solution:** Just switch to Command Prompt in VS Code:
1. Click the terminal dropdown (next to `+` icon)
2. Select "Command Prompt"
3. Run `npm install`

No settings changes needed!

---

## 📝 After Fixing

Once you can run `npm install`, continue with:
```bash
npm run dev:client
```

Then open `http://localhost:5000` in your browser.

