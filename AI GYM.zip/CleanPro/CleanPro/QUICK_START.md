# ⚡ Quick Start Guide - VS Code

## 🎯 Fastest Way to Run (3 Steps)

### 1️⃣ Open VS Code
- Open Visual Studio Code
- Press `Ctrl + K` then `Ctrl + O` (or File → Open Folder)
- Select: `C:\Users\HP\Downloads\CleanPro\CleanPro`

### 2️⃣ Open Terminal & Install
- Press `` Ctrl + ` `` (backtick key) to open terminal
- Type: `npm install`
- Press Enter
- Wait 2-5 minutes for installation

### 3️⃣ Run the App
- Type: `npm run dev:client`
- Press Enter
- Wait for: `Local: http://localhost:5000`
- Open browser → Go to: `http://localhost:5000`

**Done! 🎉**

---

## 📸 Visual Guide

### Step 1: Opening Terminal
```
VS Code Window
┌─────────────────────────────────┐
│ File  Edit  View  ...           │
├─────────────────────────────────┤
│ [Explorer]  [Code Files]        │
│                                 │
│                                 │
│                                 │
├─────────────────────────────────┤ ← Press Ctrl + ` here
│ > npm install                   │ ← Terminal appears here
└─────────────────────────────────┘
```

### Step 2: After Running `npm run dev:client`
```
Terminal Output:
─────────────────────────────────────
> rest-express@1.0.0 dev:client
> vite dev --port 5000

  VITE v7.x.x  ready in 1234 ms

  ➜  Local:   http://localhost:5000/
  ➜  Network: use --host to expose

  ready in 1234 ms.
─────────────────────────────────────
```

### Step 3: Browser
```
Browser Address Bar:
┌─────────────────────────────────────┐
│ http://localhost:5000               │ ← Type this
└─────────────────────────────────────┘

You should see:
┌─────────────────────────────────────┐
│  TRAIN SMARTER                      │
│  NOT HARDER                         │
│                                     │
│  [START JOURNEY] [WATCH DEMO]       │
└─────────────────────────────────────┘
```

---

## 🛑 To Stop the Server

Press `Ctrl + C` in the terminal

---

## ❓ Need More Help?

See `README.md` for detailed troubleshooting and advanced setup.

