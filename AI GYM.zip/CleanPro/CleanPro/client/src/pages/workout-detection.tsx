import { useState } from "react";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Activity, Timer, Flame, Calculator } from "lucide-react";

// Exercise types with MET (Metabolic Equivalent) values for calorie calculation
// MET values represent the energy cost of activities
const exerciseTypes = [
  { name: "Running (6 mph)", met: 9.8 },
  { name: "Running (8 mph)", met: 11.5 },
  { name: "Cycling (moderate)", met: 8.0 },
  { name: "Cycling (vigorous)", met: 10.0 },
  { name: "Swimming", met: 8.0 },
  { name: "Weightlifting", met: 6.0 },
  { name: "HIIT", met: 8.5 },
  { name: "Yoga", met: 3.0 },
  { name: "Walking (3.5 mph)", met: 3.8 },
  { name: "Jumping Rope", met: 12.0 },
  { name: "Rowing", met: 7.0 },
  { name: "Elliptical", met: 7.5 },
];

export default function WorkoutDetection() {
  const { toast } = useToast();
  const [exerciseType, setExerciseType] = useState("");
  const [duration, setDuration] = useState("");
  const [weight, setWeight] = useState("");
  const [caloriesBurned, setCaloriesBurned] = useState<number | null>(null);

  // Calculate calories burned using MET formula
  // Calories = MET × weight (kg) × time (hours)
  const calculateCalories = () => {
    if (!exerciseType || !duration || !weight) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields to calculate calories.",
        variant: "destructive",
      });
      return;
    }

    const selectedExercise = exerciseTypes.find((e) => e.name === exerciseType);
    if (!selectedExercise) return;

    const weightKg = parseFloat(weight);
    const durationHours = parseFloat(duration) / 60; // Convert minutes to hours

    if (isNaN(weightKg) || isNaN(durationHours) || weightKg <= 0 || durationHours <= 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid numbers for weight and duration.",
        variant: "destructive",
      });
      return;
    }

    // MET formula: Calories = MET × weight (kg) × time (hours)
    const calories = selectedExercise.met * weightKg * durationHours;
    setCaloriesBurned(Math.round(calories));

    // Save to workout history
    const workoutHistory = JSON.parse(localStorage.getItem("workoutHistory") || "[]");
    const today = new Date().toISOString().split('T')[0];
    
    workoutHistory.push({
      date: today,
      day: new Date().toLocaleDateString('en-US', { weekday: 'long' }),
      goal: localStorage.getItem("fitnessGoal") || "weight-loss",
      exerciseType: exerciseType,
      duration: `${duration} minutes`,
      caloriesBurned: Math.round(calories),
      completed: true,
    });
    
    localStorage.setItem("workoutHistory", JSON.stringify(workoutHistory));

    toast({
      title: "Calories Calculated!",
      description: `You burned approximately ${Math.round(calories)} calories.`,
    });
  };

  return (
    <div className="min-h-screen pb-20 font-sans">
      <Navbar />
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-extrabold font-heading text-gray-800 mb-2">
              Workout Detection
            </h1>
            <p className="text-gray-500 text-lg">
              Calculate calories burned based on your exercise type and duration
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="size-5 text-[#6C63FF]" />
                  Exercise Calculator
                </CardTitle>
                <CardDescription>
                  Enter your workout details to calculate calories burned
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="exercise">Exercise Type</Label>
                  <Select value={exerciseType} onValueChange={setExerciseType}>
                    <SelectTrigger id="exercise">
                      <SelectValue placeholder="Select exercise type" />
                    </SelectTrigger>
                    <SelectContent>
                      {exerciseTypes.map((exercise) => (
                        <SelectItem key={exercise.name} value={exercise.name}>
                          {exercise.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <div className="relative">
                    <Timer className="absolute left-3 top-3 size-4 text-gray-400" />
                    <Input
                      id="duration"
                      type="number"
                      placeholder="e.g., 30"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="weight">Your Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="e.g., 70"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                  />
                </div>

                <Button
                  onClick={calculateCalories}
                  className="w-full gradient-primary h-12 text-lg font-bold"
                >
                  <Calculator className="mr-2 size-5" />
                  Calculate Calories
                </Button>
              </CardContent>
            </Card>

            {/* Results Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Flame className="size-5 text-[#FF6F61]" />
                  Results
                </CardTitle>
                <CardDescription>
                  Your calculated calorie burn
                </CardDescription>
              </CardHeader>
              <CardContent>
                {caloriesBurned !== null ? (
                  <div className="text-center py-12">
                    <div className="inline-flex items-center justify-center size-32 rounded-full bg-gradient-to-br from-[#6C63FF] to-[#FF6F61] mb-6 shadow-xl">
                      <Flame className="size-16 text-white" />
                    </div>
                    <h3 className="text-5xl font-extrabold text-gray-800 mb-2">
                      {caloriesBurned}
                    </h3>
                    <p className="text-xl text-gray-600 font-medium">calories burned</p>
                    <div className="mt-8 p-4 bg-gray-50 rounded-xl">
                      <p className="text-sm text-gray-500 mb-2">Exercise:</p>
                      <p className="font-bold text-gray-800">{exerciseType}</p>
                      <p className="text-sm text-gray-500 mt-4 mb-2">Duration:</p>
                      <p className="font-bold text-gray-800">{duration} minutes</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="inline-flex items-center justify-center size-32 rounded-full bg-gray-100 mb-6">
                      <Calculator className="size-16 text-gray-400" />
                    </div>
                    <p className="text-gray-500 text-lg">
                      Enter your workout details and click "Calculate Calories" to see results
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Info Section */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>How It Works</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 leading-relaxed">
                Calories are calculated using the MET (Metabolic Equivalent of Task) formula. 
                MET values represent the energy cost of physical activities. The formula used is:
              </p>
              <div className="mt-4 p-4 bg-gray-50 rounded-xl font-mono text-sm">
                Calories = MET × Weight (kg) × Time (hours)
              </div>
              <p className="text-gray-600 mt-4 text-sm">
                Your workout is automatically saved to your workout history for tracking progress.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

