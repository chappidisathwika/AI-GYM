import { useState } from "react";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Utensils, Calculator, Plus, X, Flame } from "lucide-react";

// Common foods with approximate calories per serving
const commonFoods: Record<string, number> = {
  "Chicken Breast (100g)": 165,
  "Salmon (100g)": 208,
  "Rice (cooked, 100g)": 130,
  "Pasta (cooked, 100g)": 131,
  "Potato (100g)": 77,
  "Broccoli (100g)": 34,
  "Spinach (100g)": 23,
  "Egg (1 large)": 72,
  "Bread (1 slice)": 75,
  "Oatmeal (100g)": 68,
  "Banana (1 medium)": 105,
  "Apple (1 medium)": 95,
  "Greek Yogurt (100g)": 59,
  "Almonds (30g)": 164,
  "Avocado (100g)": 160,
  "Olive Oil (1 tbsp)": 119,
  "Cheese (30g)": 113,
  "Milk (250ml)": 150,
  "Orange (1 medium)": 62,
  "Strawberries (100g)": 32,
};

interface MealItem {
  id: string;
  name: string;
  quantity: string;
  calories: number;
}

export default function SmartDietician() {
  const { toast } = useToast();
  const [meals, setMeals] = useState<MealItem[]>([]);
  const [selectedFood, setSelectedFood] = useState("");
  const [quantity, setQuantity] = useState("");
  const [customFood, setCustomFood] = useState("");
  const [customCalories, setCustomCalories] = useState("");

  const addMeal = () => {
    if (selectedFood && quantity) {
      const baseCalories = commonFoods[selectedFood] || 0;
      const quantityNum = parseFloat(quantity);
      
      if (isNaN(quantityNum) || quantityNum <= 0) {
        toast({
          title: "Invalid Quantity",
          description: "Please enter a valid quantity.",
          variant: "destructive",
        });
        return;
      }

      // Calculate calories based on quantity (assuming quantity is in servings/units)
      const calories = Math.round(baseCalories * quantityNum);

      const newMeal: MealItem = {
        id: Date.now().toString(),
        name: selectedFood,
        quantity: quantity,
        calories: calories,
      };

      setMeals([...meals, newMeal]);
      setSelectedFood("");
      setQuantity("");
    } else if (customFood && customCalories) {
      const caloriesNum = parseFloat(customCalories);
      
      if (isNaN(caloriesNum) || caloriesNum <= 0) {
        toast({
          title: "Invalid Calories",
          description: "Please enter valid calories.",
          variant: "destructive",
        });
        return;
      }

      const newMeal: MealItem = {
        id: Date.now().toString(),
        name: customFood,
        quantity: "1 serving",
        calories: Math.round(caloriesNum),
      };

      setMeals([...meals, newMeal]);
      setCustomFood("");
      setCustomCalories("");
    } else {
      toast({
        title: "Missing Information",
        description: "Please select a food or enter custom food details.",
        variant: "destructive",
      });
    }
  };

  const removeMeal = (id: string) => {
    setMeals(meals.filter((meal) => meal.id !== id));
  };

  const totalCalories = meals.reduce((sum, meal) => sum + meal.calories, 0);

  const saveMealPlan = () => {
    if (meals.length === 0) {
      toast({
        title: "No Meals",
        description: "Please add at least one meal to save.",
        variant: "destructive",
      });
      return;
    }

    const mealPlan = {
      date: new Date().toISOString().split('T')[0],
      meals: meals,
      totalCalories: totalCalories,
    };

    const mealHistory = JSON.parse(localStorage.getItem("mealHistory") || "[]");
    mealHistory.push(mealPlan);
    localStorage.setItem("mealHistory", JSON.stringify(mealHistory));

    toast({
      title: "Meal Plan Saved!",
      description: `Your meal plan with ${totalCalories} calories has been saved.`,
    });
  };

  return (
    <div className="min-h-screen pb-20 font-sans">
      <Navbar />
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-extrabold font-heading text-gray-800 mb-2">
              Smart Dietician
            </h1>
            <p className="text-gray-500 text-lg">
              Calculate total calories for your meals
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Utensils className="size-5 text-[#FF6F61]" />
                  Add Meals
                </CardTitle>
                <CardDescription>
                  Select from common foods or add custom items
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Common Foods */}
                <div className="space-y-2">
                  <Label htmlFor="food">Select Food</Label>
                  <select
                    id="food"
                    value={selectedFood}
                    onChange={(e) => setSelectedFood(e.target.value)}
                    className="w-full h-10 px-3 rounded-md border border-gray-300 bg-white"
                  >
                    <option value="">Choose a food...</option>
                    {Object.keys(commonFoods).map((food) => (
                      <option key={food} value={food}>
                        {food} ({commonFoods[food]} cal)
                      </option>
                    ))}
                  </select>
                </div>

                {selectedFood && (
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantity (servings/units)</Label>
                    <Input
                      id="quantity"
                      type="number"
                      placeholder="e.g., 2"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                    />
                  </div>
                )}

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-white px-2 text-gray-500">Or</span>
                  </div>
                </div>

                {/* Custom Food */}
                <div className="space-y-2">
                  <Label htmlFor="customFood">Custom Food Name</Label>
                  <Input
                    id="customFood"
                    placeholder="e.g., Homemade Pizza"
                    value={customFood}
                    onChange={(e) => setCustomFood(e.target.value)}
                  />
                </div>

                {customFood && (
                  <div className="space-y-2">
                    <Label htmlFor="customCalories">Calories</Label>
                    <Input
                      id="customCalories"
                      type="number"
                      placeholder="e.g., 350"
                      value={customCalories}
                      onChange={(e) => setCustomCalories(e.target.value)}
                    />
                  </div>
                )}

                <Button
                  onClick={addMeal}
                  className="w-full bg-[#FF6F61] hover:bg-[#e55a4f] h-12 text-lg font-bold"
                >
                  <Plus className="mr-2 size-5" />
                  Add to Meal
                </Button>
              </CardContent>
            </Card>

            {/* Results Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Flame className="size-5 text-[#FF6F61]" />
                  Meal Summary
                </CardTitle>
                <CardDescription>
                  Total calories for your meal
                </CardDescription>
              </CardHeader>
              <CardContent>
                {meals.length > 0 ? (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      {meals.map((meal) => (
                        <div
                          key={meal.id}
                          className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-200"
                        >
                          <div className="flex-1">
                            <p className="font-bold text-gray-800">{meal.name}</p>
                            <p className="text-sm text-gray-500">
                              {meal.quantity} • {meal.calories} cal
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeMeal(meal.id)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          >
                            <X className="size-4" />
                          </Button>
                        </div>
                      ))}
                    </div>

                    <div className="pt-4 border-t border-gray-200">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-lg font-bold text-gray-800">Total Calories:</span>
                        <span className="text-3xl font-extrabold text-[#FF6F61]">
                          {totalCalories}
                        </span>
                      </div>
                      <Button
                        onClick={saveMealPlan}
                        className="w-full gradient-primary h-12 text-lg font-bold"
                      >
                        Save Meal Plan
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="inline-flex items-center justify-center size-32 rounded-full bg-gray-100 mb-6">
                      <Utensils className="size-16 text-gray-400" />
                    </div>
                    <p className="text-gray-500 text-lg">
                      Add meals to calculate total calories
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

