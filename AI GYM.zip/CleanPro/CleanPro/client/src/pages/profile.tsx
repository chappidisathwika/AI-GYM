import { useState, useEffect } from "react";
import { Navbar } from "@/components/layout/navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { User, Mail, Calendar, Target, TrendingUp, Camera, Trash2, Upload, Image as ImageIcon, CheckCircle2, AlertCircle, XCircle, BarChart3 } from "lucide-react";

interface ProfileData {
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: string;
  photo: string | null;
}

interface WorkoutHistory {
  date: string;
  day: string;
  goal: string;
  caloriesBurned: number;
  completed: boolean;
}

interface MealHistory {
  date: string;
  meals: any[];
  totalCalories: number;
}

type ProgressStatus = "good" | "average" | "bad";

export default function Profile() {
  const { toast } = useToast();
  const [profile, setProfile] = useState<ProfileData>({
    firstName: "",
    lastName: "",
    email: "",
    dateOfBirth: "",
    photo: null,
  });

  const [workoutsCompleted, setWorkoutsCompleted] = useState(0);
  const [totalCaloriesBurned, setTotalCaloriesBurned] = useState(0);
  const [currentStreak, setCurrentStreak] = useState(0);
  const [fitnessGoal, setFitnessGoal] = useState("Weight Loss");
  const [overallProgress, setOverallProgress] = useState<ProgressStatus>("bad");
  const [progressMessage, setProgressMessage] = useState("");

  // Function to calculate and update stats
  const calculateStats = () => {
    // Load workout history and calculate stats
    const workoutHistory = localStorage.getItem("workoutHistory");
    let completed: WorkoutHistory[] = [];
    
    if (workoutHistory) {
      const history: WorkoutHistory[] = JSON.parse(workoutHistory);
      completed = history.filter(w => w.completed);
      setWorkoutsCompleted(completed.length);
      
      const totalCalories = completed.reduce((sum, w) => sum + w.caloriesBurned, 0);
      setTotalCaloriesBurned(totalCalories);

      // Calculate streak
      const sortedDates = completed
        .map(w => new Date(w.date).getTime())
        .sort((a, b) => b - a);
      
      let streak = 0;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      for (let i = 0; i < sortedDates.length; i++) {
        const workoutDate = new Date(sortedDates[i]);
        workoutDate.setHours(0, 0, 0, 0);
        const daysDiff = Math.floor((today.getTime() - workoutDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (daysDiff === i) {
          streak++;
        } else {
          break;
        }
      }
      setCurrentStreak(streak);
    } else {
      setWorkoutsCompleted(0);
      setTotalCaloriesBurned(0);
      setCurrentStreak(0);
    }

    // Load meal history
    const mealHistory = localStorage.getItem("mealHistory");
    let meals: MealHistory[] = [];
    if (mealHistory) {
      meals = JSON.parse(mealHistory);
    }

    // Calculate overall progress
    calculateOverallProgress(completed, meals);

    // Load fitness goal
    const savedGoal = localStorage.getItem("fitnessGoal");
    if (savedGoal) {
      setFitnessGoal(savedGoal === "weight-loss" ? "Weight Loss" : "Muscle Gain");
    }
  };

  // Calculate overall progress based on workouts and nutrition
  const calculateOverallProgress = (workouts: WorkoutHistory[], meals: MealHistory[]) => {
    const last7Days = 7;
    const today = new Date();
    
    // Count workouts in last 7 days
    const recentWorkouts = workouts.filter(w => {
      const workoutDate = new Date(w.date);
      const daysDiff = Math.floor((today.getTime() - workoutDate.getTime()) / (1000 * 60 * 60 * 24));
      return daysDiff <= last7Days;
    });

    // Count meals in last 7 days
    const recentMeals = meals.filter(m => {
      const mealDate = new Date(m.date);
      const daysDiff = Math.floor((today.getTime() - mealDate.getTime()) / (1000 * 60 * 60 * 24));
      return daysDiff <= last7Days;
    });

    // Calculate scores
    const workoutScore = Math.min(recentWorkouts.length / 4, 1) * 50; // 4+ workouts = 50 points
    const nutritionScore = Math.min(recentMeals.length / 5, 1) * 30; // 5+ meals = 30 points
    const consistencyScore = Math.min(workouts.length / 10, 1) * 20; // 10+ total workouts = 20 points
    
    const totalScore = workoutScore + nutritionScore + consistencyScore;

    // Determine status
    let status: ProgressStatus;
    let message: string;

    if (totalScore >= 70) {
      status = "good";
      message = "Excellent progress! You're consistently working out and tracking your nutrition. Keep up the great work!";
    } else if (totalScore >= 40) {
      status = "average";
      message = "Good progress, but there's room for improvement. Try to be more consistent with workouts and meal tracking.";
    } else {
      status = "bad";
      message = "You need to focus more on regular workouts and nutrition tracking. Start with small, consistent steps!";
    }

    setOverallProgress(status);
    setProgressMessage(message);
  };

  // Load profile data from localStorage
  useEffect(() => {
    const savedProfile = localStorage.getItem("userProfile");
    if (savedProfile) {
      const parsed = JSON.parse(savedProfile);
      setProfile(parsed);
    }

    calculateStats();

    // Refresh stats when page becomes visible
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        calculateStats();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  const handleInputChange = (field: keyof ProfileData, value: string) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "File too large",
          description: "Please upload an image smaller than 5MB",
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setProfile(prev => ({ ...prev, photo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    setProfile(prev => ({ ...prev, photo: null }));
    toast({
      title: "Photo removed",
      description: "Your profile photo has been removed.",
    });
  };

  const handleUploadFromFiles = () => {
    document.getElementById("photo-upload")?.click();
  };

  const handleCameraUpload = () => {
    // For now, this also opens file picker
    // In future, this could open webcam
    document.getElementById("photo-upload")?.click();
  };

  const handleSave = () => {
    // Save to localStorage
    localStorage.setItem("userProfile", JSON.stringify(profile));
    
    toast({
      title: "Profile saved!",
      description: "Your profile information has been updated successfully.",
    });
  };

  const getInitials = () => {
    const first = profile.firstName.charAt(0).toUpperCase();
    const last = profile.lastName.charAt(0).toUpperCase();
    return first + last || "U";
  };

  return (
    <div className="min-h-screen pb-20 font-sans">
      <Navbar />
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-extrabold font-heading text-gray-800 mb-2">
            Profile Settings
          </h1>
          <p className="text-gray-500 text-lg mb-8">Manage your account and preferences.</p>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Profile Info Card */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="size-5 text-[#6C63FF]" />
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Profile Photo Upload */}
                <div className="flex flex-col items-center gap-4 pb-6 border-b border-gray-200">
                  <div className="relative">
                    <Avatar className="size-32 border-4 border-white shadow-lg">
                      <AvatarImage src={profile.photo || undefined} alt="Profile" />
                      <AvatarFallback className="bg-gradient-to-br from-[#6C63FF] to-[#FF6F61] text-white flex items-center justify-center">
                        <Camera className="size-12 text-white" />
                      </AvatarFallback>
                    </Avatar>
                    
                    {/* Camera Icon with Dropdown Menu */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button
                          className="absolute bottom-0 right-0 p-2 bg-[#6C63FF] rounded-full cursor-pointer hover:bg-[#5a52e6] transition-colors shadow-lg"
                        >
                          <Camera className="size-4 text-white" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem 
                          onClick={handleRemovePhoto} 
                          className="cursor-pointer text-red-600 focus:text-red-600 focus:bg-red-50"
                        >
                          <Trash2 className="mr-2 size-4" />
                          Delete
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={handleCameraUpload} className="cursor-pointer">
                          <Camera className="mr-2 size-4" />
                          Camera
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={handleUploadFromFiles} className="cursor-pointer">
                          <Upload className="mr-2 size-4" />
                          Upload from Files
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                    
                    <input
                      id="photo-upload"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handlePhotoUpload}
                    />
                  </div>
                  <div className="text-center">
                    <Label className="text-sm text-gray-500">
                      Click camera icon to manage your photo
                    </Label>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input 
                      id="firstName" 
                      placeholder="John" 
                      value={profile.firstName}
                      onChange={(e) => handleInputChange("firstName", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input 
                      id="lastName" 
                      placeholder="Doe" 
                      value={profile.lastName}
                      onChange={(e) => handleInputChange("lastName", e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 size-4 text-gray-400" />
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="john.doe@example.com" 
                      className="pl-10"
                      value={profile.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-3 size-4 text-gray-400" />
                    <Input 
                      id="dateOfBirth" 
                      type="date" 
                      className="pl-10"
                      value={profile.dateOfBirth}
                      onChange={(e) => handleInputChange("dateOfBirth", e.target.value)}
                    />
                  </div>
                </div>
                <Button 
                  onClick={handleSave}
                  className="w-full gradient-primary"
                >
                  Save Changes
                </Button>
              </CardContent>
            </Card>

            {/* Stats Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="size-5 text-[#6C63FF]" />
                  Your Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="goal">Fitness Goal</Label>
                  <div className="flex items-center gap-2">
                    <Target className="size-4 text-[#6C63FF]" />
                    <span className="text-sm font-medium text-gray-700">{fitnessGoal}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Workouts Completed</Label>
                  <p className="text-2xl font-bold text-[#6C63FF]">{workoutsCompleted}</p>
                </div>
                <div className="space-y-2">
                  <Label>Total Calories Burned</Label>
                  <p className="text-2xl font-bold text-[#FF6F61]">{totalCaloriesBurned.toLocaleString()}</p>
                </div>
                <div className="space-y-2">
                  <Label>Current Streak</Label>
                  <p className="text-2xl font-bold text-[#2ECC71]">{currentStreak} {currentStreak === 1 ? 'day' : 'days'}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Performance Analytics Card */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="size-5 text-[#6C63FF]" />
                Performance Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`p-6 rounded-xl border-2 ${
                overallProgress === "good" 
                  ? "bg-green-50 border-green-200" 
                  : overallProgress === "average"
                  ? "bg-yellow-50 border-yellow-200"
                  : "bg-red-50 border-red-200"
              }`}>
                <div className="flex items-start gap-4">
                  <div className={`flex-shrink-0 ${
                    overallProgress === "good" 
                      ? "text-green-600" 
                      : overallProgress === "average"
                      ? "text-yellow-600"
                      : "text-red-600"
                  }`}>
                    {overallProgress === "good" && <CheckCircle2 className="size-8" />}
                    {overallProgress === "average" && <AlertCircle className="size-8" />}
                    {overallProgress === "bad" && <XCircle className="size-8" />}
                  </div>
                  <div className="flex-1">
                    <h3 className={`text-xl font-bold mb-2 ${
                      overallProgress === "good" 
                        ? "text-green-800" 
                        : overallProgress === "average"
                        ? "text-yellow-800"
                        : "text-red-800"
                    }`}>
                      Progress: {overallProgress === "good" ? "Excellent" : overallProgress === "average" ? "Good" : "Needs Improvement"}
                    </h3>
                    <p className={`text-base leading-relaxed ${
                      overallProgress === "good" 
                        ? "text-green-700" 
                        : overallProgress === "average"
                        ? "text-yellow-700"
                        : "text-red-700"
                    }`}>
                      {progressMessage}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

