import { useState, useEffect, useRef } from "react";
import { Navbar } from "@/components/layout/navbar";
import { weeklyPlans as plans, GoalType } from "@/lib/data"; 
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Flame, Utensils, Timer, Dumbbell, ChevronRight, CheckCircle2, TrendingUp, Activity, Play, Pause, Square } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Dashboard() {
  const [goal, setGoal] = useState<GoalType>("weight-loss");
  const [selectedDay, setSelectedDay] = useState<string>("Monday");
  const [isExerciseDialogOpen, setIsExerciseDialogOpen] = useState(false);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [totalTime, setTotalTime] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Save fitness goal to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("fitnessGoal", goal);
  }, [goal]);

  const currentGoalPlans = plans[goal];
  const currentPlan = currentGoalPlans.find((p) => p.day === selectedDay) || currentGoalPlans[0];
  const allDays = currentGoalPlans.map((p) => p.day);

  // Design Doc Colors
  const accentColor = goal === "weight-loss" ? "text-[#FF8C42]" : "text-[#2ECC71]";
  const accentBg = goal === "weight-loss" ? "bg-[#FF8C42]" : "bg-[#2ECC71]";
  const accentBorder = goal === "weight-loss" ? "border-[#FF8C42]" : "border-[#2ECC71]";
  const accentGradient = goal === "weight-loss" ? "from-[#FF8C42] to-red-500" : "from-[#2ECC71] to-emerald-600";

  // Parse duration string to seconds
  const parseDuration = (duration: string): number => {
    const match = duration.match(/(\d+)\s*(minute|min|sec|second|hour|hr)/i);
    if (!match) return 0;
    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    if (unit.includes('hour') || unit.includes('hr')) return value * 3600;
    if (unit.includes('min')) return value * 60;
    return value;
  };

  // Start timer
  const startTimer = () => {
    if (currentPlan.exercise.exercises.length === 0) return;
    
    const firstExercise = currentPlan.exercise.exercises[0];
    const duration = parseDuration(firstExercise.duration);
    
    setTimeRemaining(duration);
    setCurrentExerciseIndex(0);
    setIsTimerRunning(true);
    setIsExerciseDialogOpen(false);
    
    // Calculate total time
    const total = currentPlan.exercise.exercises.reduce((sum, ex) => sum + parseDuration(ex.duration), 0);
    setTotalTime(total);
  };

  // Timer effect
  useEffect(() => {
    if (isTimerRunning && timeRemaining > 0) {
      intervalRef.current = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            // Move to next exercise
            if (currentExerciseIndex < currentPlan.exercise.exercises.length - 1) {
              const nextIndex = currentExerciseIndex + 1;
              setCurrentExerciseIndex(nextIndex);
              const nextExercise = currentPlan.exercise.exercises[nextIndex];
              return parseDuration(nextExercise.duration);
            } else {
              // All exercises done - save workout completion
              setIsTimerRunning(false);
              
              // Save workout completion
              const workoutHistory = JSON.parse(localStorage.getItem("workoutHistory") || "[]");
              const today = new Date().toISOString().split('T')[0];
              
              // Check if workout already completed today
              const alreadyCompleted = workoutHistory.some(
                (w: any) => w.date === today && w.day === selectedDay && w.goal === goal
              );

              if (!alreadyCompleted) {
                const newWorkout = {
                  date: today,
                  day: selectedDay,
                  goal: goal,
                  caloriesBurned: currentPlan.exercise.caloriesBurned,
                  completed: true,
                };
                
                workoutHistory.push(newWorkout);
                localStorage.setItem("workoutHistory", JSON.stringify(workoutHistory));
              }
              
              return 0;
            }
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isTimerRunning, timeRemaining, currentExerciseIndex, currentPlan.exercise.exercises, selectedDay, goal, currentPlan.exercise.caloriesBurned]);

  // Format time
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const pauseTimer = () => {
    setIsTimerRunning(false);
  };

  const resumeTimer = () => {
    setIsTimerRunning(true);
  };

  const stopTimer = () => {
    setIsTimerRunning(false);
    setTimeRemaining(0);
    setCurrentExerciseIndex(0);
    setTotalTime(0);
  };

  return (
    <div className="min-h-screen pb-20 font-sans">
      <Navbar />
      
      <div className="container mx-auto px-4 py-12">
        {/* Header & Goal Toggle */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end mb-10 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
                <div className={`p-2 rounded-lg ${accentBg} bg-opacity-20`}>
                    <TrendingUp className={`size-5 ${accentColor}`} />
                </div>
                <span className={`font-bold uppercase tracking-wider text-sm ${accentColor}`}>
                    {goal === "weight-loss" ? "Fat Burn Mode" : "Hypertrophy Mode"}
                </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold font-heading text-gray-800 mb-2">
              Today's Plan
            </h1>
            <p className="text-gray-500 text-lg">Stay consistent to reach your goals.</p>
          </div>
          
          <div className="bg-white p-1.5 rounded-2xl flex shadow-sm border border-gray-100">
            <button
              onClick={() => setGoal("weight-loss")}
              className={`px-6 py-3 rounded-xl text-sm font-bold uppercase tracking-wide transition-all duration-300 ${
                goal === "weight-loss" 
                  ? "bg-gradient-to-r from-[#FF8C42] to-red-500 text-white shadow-lg transform scale-105" 
                  : "text-gray-500 hover:bg-white/50 hover:text-gray-800"
              }`}
            >
              Weight Loss
            </button>
            <button
              onClick={() => setGoal("weight-gain")}
              className={`px-6 py-3 rounded-xl text-sm font-bold uppercase tracking-wide transition-all duration-300 ${
                goal === "weight-gain" 
                  ? "bg-gradient-to-r from-[#2ECC71] to-emerald-600 text-white shadow-lg transform scale-105" 
                  : "text-gray-500 hover:bg-white/50 hover:text-gray-800"
              }`}
            >
              Muscle Gain
            </button>
          </div>
        </div>

        {/* Day Selector */}
        <div className="flex overflow-x-auto pb-6 mb-4 gap-3 no-scrollbar">
          {allDays.map((day) => (
            <button
              key={day}
              onClick={() => setSelectedDay(day)}
              className={`flex-shrink-0 px-6 py-3 rounded-full border-2 text-sm font-bold transition-all whitespace-nowrap shadow-sm ${
                selectedDay === day
                  ? `${accentBorder} ${accentBg} text-white shadow-md transform -translate-y-1`
                  : "bg-white border-transparent text-gray-500 hover:bg-white/80 hover:shadow-sm"
              }`}
            >
              {day}
            </button>
          ))}
        </div>

        {/* Main Content Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={`${goal}-${selectedDay}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            {/* Exercise Card */}
            <div className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-xl hover:shadow-2xl transition-all duration-300 group">
              <div className="relative h-72 overflow-hidden">
                <img 
                  src={currentPlan.exercise.image} 
                  alt={currentPlan.exercise.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${goal === 'weight-loss' ? 'from-orange-900/80' : 'from-green-900/80'} to-transparent`} />
                
                <div className="absolute top-4 right-4">
                    <div className="bg-white/20 backdrop-blur-md p-2 rounded-full border border-white/30">
                        <Activity className="text-white size-6" />
                    </div>
                </div>

                <div className="absolute bottom-6 left-6 right-6 text-white">
                  <Badge className={`mb-3 border-none px-3 py-1 text-xs font-bold uppercase tracking-widest ${accentBg} text-white`}>
                    Workout
                  </Badge>
                  <h2 className="text-3xl font-extrabold font-heading mb-2">{currentPlan.exercise.title}</h2>
                  <div className="flex items-center gap-4 text-sm font-medium text-white/90">
                     <span className="flex items-center gap-1"><Timer className="size-4" /> {currentPlan.exercise.duration}</span>
                     <span className="flex items-center gap-1"><Flame className="size-4" /> {currentPlan.exercise.caloriesBurned} kcal</span>
                  </div>
                </div>
              </div>
              
              <div className="p-8">
                <p className="text-gray-600 mb-8 leading-relaxed text-lg">
                  {currentPlan.exercise.description}
                </p>

                <div className="flex flex-wrap gap-3 mb-8">
                  {currentPlan.exercise.focus.map((f) => (
                    <Badge key={f} variant="secondary" className="bg-gray-100 text-gray-700 hover:bg-gray-200 px-4 py-1.5 rounded-full text-sm font-medium border border-gray-200">
                      {f}
                    </Badge>
                  ))}
                </div>

                <Button 
                  onClick={() => setIsExerciseDialogOpen(true)}
                  className={`w-full h-14 text-lg font-bold rounded-xl bg-gradient-to-r ${accentGradient} shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all`}
                >
                  START SESSION <ChevronRight className="ml-2 size-5" />
                </Button>
              </div>
            </div>

            {/* Diet Card */}
            <div className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-xl hover:shadow-2xl transition-all duration-300 group">
              <div className="relative h-72 overflow-hidden">
                <img 
                  src={currentPlan.diet.image} 
                  alt="Healthy Meal"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${goal === 'weight-loss' ? 'from-orange-900/80' : 'from-green-900/80'} to-transparent`} />
                
                <div className="absolute top-4 right-4">
                    <div className="bg-white/20 backdrop-blur-md p-2 rounded-full border border-white/30">
                        <Utensils className="text-white size-6" />
                    </div>
                </div>

                <div className="absolute bottom-6 left-6 right-6 text-white">
                  <Badge className={`mb-3 border-none px-3 py-1 text-xs font-bold uppercase tracking-widest bg-blue-500 text-white`}>
                    Nutrition
                  </Badge>
                  <h2 className="text-3xl font-extrabold font-heading mb-2">{currentPlan.diet.totalCalories} kcal</h2>
                  <p className="text-white/80 font-medium">Daily Target Intake</p>
                </div>
              </div>
              
              <div className="p-8">
                <div className="grid grid-cols-3 gap-4 mb-8">
                  {[
                      { label: "Protein", val: currentPlan.diet.macros.p, color: "text-blue-600", bg: "bg-blue-50" },
                      { label: "Carbs", val: currentPlan.diet.macros.c, color: "text-purple-600", bg: "bg-purple-50" },
                      { label: "Fats", val: currentPlan.diet.macros.f, color: "text-orange-600", bg: "bg-orange-50" }
                  ].map((macro) => (
                    <div key={macro.label} className={`${macro.bg} p-4 rounded-2xl text-center border border-white/50 shadow-sm`}>
                        <span className="block text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">{macro.label}</span>
                        <span className={`text-xl font-black ${macro.color}`}>{macro.val}</span>
                    </div>
                  ))}
                </div>

                <div className="space-y-3 mb-8">
                  {[
                    { label: "Breakfast", value: currentPlan.diet.breakfast },
                    { label: "Lunch", value: currentPlan.diet.lunch },
                    { label: "Dinner", value: currentPlan.diet.dinner },
                    { label: "Snacks", value: currentPlan.diet.snacks.join(", ") },
                  ].map((meal, idx) => (
                    <div key={idx} className="flex items-start gap-4 p-3 rounded-xl hover:bg-white/50 transition-colors border border-transparent hover:border-gray-100">
                      <div className={`mt-1 ${goal === "weight-loss" ? "bg-orange-100 text-orange-600" : "bg-green-100 text-green-600"} p-1.5 rounded-full`}>
                        <CheckCircle2 className="size-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">{meal.label}</span>
                        <p className="text-base font-medium text-gray-800">{meal.value}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Exercise Dialog */}
        <Dialog open={isExerciseDialogOpen} onOpenChange={setIsExerciseDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-3xl font-extrabold font-heading">
                {currentPlan.exercise.title}
              </DialogTitle>
              <DialogDescription className="text-base">
                {currentPlan.exercise.description}
              </DialogDescription>
            </DialogHeader>
            
            <div className="mt-6 space-y-4">
              <div className="flex items-center gap-4 mb-6 p-4 rounded-xl bg-gradient-to-r from-gray-50 to-gray-100">
                <div className="flex items-center gap-2">
                  <Timer className={`size-5 ${accentColor}`} />
                  <span className="font-bold text-gray-700">Total Duration: {currentPlan.exercise.duration}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Flame className={`size-5 ${accentColor}`} />
                  <span className="font-bold text-gray-700">{currentPlan.exercise.caloriesBurned} kcal</span>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-xl font-bold text-gray-800 mb-4">Exercise Routine</h3>
                {currentPlan.exercise.exercises.map((exercise, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between p-4 rounded-xl border-2 border-gray-200 hover:border-gray-300 hover:shadow-md transition-all bg-white"
                  >
                    <div className="flex items-center gap-4">
                      <div className={`flex items-center justify-center w-10 h-10 rounded-full ${accentBg} bg-opacity-20 ${accentColor} font-bold text-lg`}>
                        {index + 1}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-800 text-lg">{exercise.name}</h4>
                        {exercise.sets && (
                          <p className="text-sm text-gray-500 mt-1">{exercise.sets} • {exercise.reps}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-100">
                      <Timer className="size-4 text-gray-600" />
                      <span className="font-bold text-gray-700">{exercise.duration}</span>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-8 pt-6 border-t border-gray-200">
                <Button 
                  onClick={startTimer}
                  className={`w-full h-12 text-lg font-bold rounded-xl bg-gradient-to-r ${accentGradient} shadow-lg hover:shadow-xl`}
                >
                  Got it! Let's Start <Play className="ml-2 size-5" />
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Timer Dialog */}
        <Dialog open={isTimerRunning || (timeRemaining > 0 && !isTimerRunning)} onOpenChange={(open) => {
          if (!open && timeRemaining > 0) {
            stopTimer();
          }
        }}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-2xl font-extrabold font-heading text-center">
                {currentPlan.exercise.exercises[currentExerciseIndex]?.name || "Workout Complete!"}
              </DialogTitle>
              <DialogDescription className="text-center">
                {timeRemaining > 0 
                  ? `Exercise ${currentExerciseIndex + 1} of ${currentPlan.exercise.exercises.length}`
                  : "Great job! You've completed all exercises!"}
              </DialogDescription>
            </DialogHeader>
            
            <div className="mt-6 space-y-6">
              {timeRemaining > 0 ? (
                <>
                  <div className="text-center">
                    <div className={`text-6xl font-bold ${accentColor} mb-4`}>
                      {formatTime(timeRemaining)}
                    </div>
                    {currentPlan.exercise.exercises[currentExerciseIndex]?.sets && (
                      <p className="text-sm text-gray-500">
                        {currentPlan.exercise.exercises[currentExerciseIndex].sets} • {currentPlan.exercise.exercises[currentExerciseIndex].reps}
                      </p>
                    )}
                  </div>
                  
                  <div className="flex gap-3">
                    {isTimerRunning ? (
                      <Button 
                        onClick={pauseTimer}
                        variant="outline"
                        className="flex-1 h-12"
                      >
                        <Pause className="mr-2 size-5" /> Pause
                      </Button>
                    ) : (
                      <Button 
                        onClick={resumeTimer}
                        className={`flex-1 h-12 bg-gradient-to-r ${accentGradient}`}
                      >
                        <Play className="mr-2 size-5" /> Resume
                      </Button>
                    )}
                    <Button 
                      onClick={stopTimer}
                      variant="outline"
                      className="flex-1 h-12"
                    >
                      <Square className="mr-2 size-5" /> Stop
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center py-4">
                  <div className="text-4xl mb-4">🎉</div>
                  <p className="text-lg font-semibold text-gray-700 mb-4">Workout Complete!</p>
                  <Button 
                    onClick={stopTimer}
                    className={`w-full h-12 bg-gradient-to-r ${accentGradient}`}
                  >
                    Close
                  </Button>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
