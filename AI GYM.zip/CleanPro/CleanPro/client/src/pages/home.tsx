import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import gymImage from "@assets/generated_images/high_energy_cardio_workout.png";
import dietImage from "@assets/generated_images/healthy_weight_loss_salad_bowl.png";
import { ArrowRight, Activity, Utensils, BarChart3 } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleFeatureClick = (featureTitle: string, action: () => void) => {
    action();
    toast({
      title: `${featureTitle} Activated`,
      description: `Navigating to ${featureTitle.toLowerCase()}...`,
    });
  };
  return (
    <div className="min-h-screen font-sans pb-20 overflow-x-hidden">
      {/* Hero Section */}
      <div className="relative min-h-[90vh] w-full flex items-center justify-center">
        {/* Professional Background with Gym and Diet Images - Subtle Visibility */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          {/* Gym Image - Left Side with Subtle Visibility */}
          <div 
            className="absolute inset-0 z-0 w-1/2"
            style={{
              backgroundImage: `url(${gymImage})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              filter: "brightness(0.25) saturate(0.6) blur(2px)",
            }}
          />
          
          {/* Diet Image - Right Side with Subtle Visibility */}
          <div 
            className="absolute inset-0 z-0 left-1/2 w-1/2"
            style={{
              backgroundImage: `url(${dietImage})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              filter: "brightness(0.25) saturate(0.6) blur(2px)",
            }}
          />
          
          {/* Professional Dark Overlay for Better Text Contrast */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/70" />
          
          {/* Subtle Accent Gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#6C63FF]/15 via-transparent to-[#FF6F61]/15" />
        </div>

        {/* Subtle Floating Shapes for Professional Look */}
        <div className="absolute top-20 left-10 w-64 h-64 bg-[#6C63FF] rounded-full mix-blend-overlay filter blur-3xl opacity-10 animate-blob"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-[#FF6F61] rounded-full mix-blend-overlay filter blur-3xl opacity-10 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-80 h-80 bg-cyan-400 rounded-full mix-blend-overlay filter blur-3xl opacity-10 animate-blob animation-delay-4000"></div>

        {/* Content */}
        <div className="relative z-10 container mx-auto px-6 flex items-center justify-center">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center max-w-4xl"
          >
            <div className="inline-flex items-center rounded-full border border-[#6C63FF]/40 bg-white/10 backdrop-blur-md px-4 py-1.5 text-sm font-bold text-white shadow-lg mb-6">
              <span className="flex h-2.5 w-2.5 rounded-full bg-[#6C63FF] mr-2 animate-pulse"></span>
              AI-Powered Fitness Revolution
            </div>
            
            <h1 className="text-5xl md:text-7xl font-extrabold text-white tracking-tight leading-[1.1] mb-6 drop-shadow-lg font-heading">
              TRAIN SMARTER <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#6C63FF] to-[#FF6F61]">
                NOT HARDER
              </span>
            </h1>
            
            <p className="text-xl text-gray-200 mb-10 max-w-lg leading-relaxed font-medium">
              Experience the future of fitness with real-time AI form correction, personalized diet plans, and behavioral coaching.
            </p>
            
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/dashboard">
                <Button size="lg" className="text-lg px-8 h-16 rounded-full gradient-primary shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 font-bold tracking-wide">
                  START JOURNEY <ArrowRight className="ml-2 size-5" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="py-24 container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 font-heading bg-clip-text text-transparent bg-gradient-to-r from-[#6C63FF] to-[#FF6F61]">
            Complete AI Ecosystem
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Everything you need to transform your body and mind, powered by advanced machine learning.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              icon: Activity,
              title: "Workout Detection",
              desc: "Calculate calories burned based on exercise time and type.",
              color: "text-[#6C63FF]",
              bg: "bg-[#6C63FF]/10",
              gradient: "from-[#6C63FF] to-blue-500",
              action: () => setLocation("/workout-detection")
            },
            {
              icon: Utensils,
              title: "Smart Dietician",
              desc: "Input meals and get total calorie count for your diet.",
              color: "text-[#FF6F61]",
              bg: "bg-[#FF6F61]/10",
              gradient: "from-[#FF6F61] to-orange-500",
              action: () => setLocation("/smart-dietician")
            },
            {
              icon: BarChart3,
              title: "Performance Analytics",
              desc: "View your overall progress based on workouts and nutrition.",
              color: "text-cyan-500",
              bg: "bg-cyan-500/10",
              gradient: "from-cyan-500 to-teal-500",
              action: () => setLocation("/profile")
            },
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              onClick={() => handleFeatureClick(feature.title, feature.action)}
              className="glass-panel p-8 rounded-3xl hover:-translate-y-2 transition-all duration-300 group cursor-pointer active:scale-95 hover:shadow-xl"
            >
              <div className={`size-14 rounded-2xl ${feature.bg} ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-sm`}>
                <feature.icon className="size-7" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-800 font-heading">{feature.title}</h3>
              <p className="text-gray-500 leading-relaxed">
                {feature.desc}
              </p>
              <div className={`h-1 w-12 rounded-full mt-6 bg-gradient-to-r ${feature.gradient} group-hover:w-full transition-all duration-300`}></div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
