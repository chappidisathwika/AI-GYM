import { Home, Activity, Utensils, User, Menu } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";

export function Navbar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: "Home", href: "/", icon: Home },
    { label: "Dashboard", href: "/dashboard", icon: Activity },
    { label: "Meal Plans", href: "/dashboard", icon: Utensils },
    { label: "Profile", href: "/profile", icon: User },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full glass-panel border-b-0 rounded-b-2xl mx-auto max-w-[98%] mt-2">
      <div className="container flex h-16 items-center justify-between px-6">
        <div className="flex items-center gap-2">
          <div className="size-9 rounded-xl gradient-primary flex items-center justify-center shadow-lg">
            <Activity className="size-5 text-white" />
          </div>
          <span className="text-2xl font-bold font-heading text-gradient-primary tracking-tight">
            AI Gym
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <a
                className={`text-sm font-medium transition-all hover:text-[#6C63FF] relative group ${
                  location === item.href
                    ? "text-[#6C63FF] font-bold"
                    : "text-gray-600"
                }`}
              >
                {item.label}
                <span className={`absolute -bottom-1 left-0 w-0 h-0.5 bg-[#6C63FF] transition-all group-hover:w-full ${location === item.href ? "w-full" : ""}`}></span>
              </a>
            </Link>
          ))}
        </div>

        {/* Mobile Nav */}
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="size-6 text-[#6C63FF]" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="glass-panel border-l border-white/40">
            <div className="flex flex-col gap-6 mt-10">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <a
                    onClick={() => setIsOpen(false)}
                    className={`flex items-center gap-4 text-lg font-medium p-3 rounded-xl transition-colors ${
                      location === item.href
                        ? "bg-[#6C63FF]/10 text-[#6C63FF]"
                        : "text-gray-600 hover:bg-white/40"
                    }`}
                  >
                    <item.icon className="size-6" />
                    {item.label}
                  </a>
                </Link>
              ))}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
}
