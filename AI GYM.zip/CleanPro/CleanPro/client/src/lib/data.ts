import weightLossExerciseImg from "@assets/generated_images/high_energy_cardio_workout.png";
import weightGainExerciseImg from "@assets/generated_images/weightlifting_muscle_gain_workout.png";
import weightLossFoodImg from "@assets/generated_images/healthy_weight_loss_salad_bowl.png";
import weightGainFoodImg from "@assets/generated_images/high_protein_muscle_gain_meal.png";
import futuristicBgImg from "@assets/generated_images/futuristic_ai_gym_interface_background.png";

// Muscle Gain Exercise Images - different image for each day
// Using available images to create visual diversity each day
// Note: Currently limited to one weight gain image, but structure allows for easy addition of unique images per day
const muscleGainExerciseImgs = [
  weightGainExerciseImg, // Monday - Heavy Chest & Triceps
  weightGainExerciseImg, // Tuesday - Back & Biceps Power
  weightGainExerciseImg, // Wednesday - Leg Day Quad Focus
  weightGainExerciseImg, // Thursday - Shoulders & Abs
  weightGainExerciseImg, // Friday - Leg Day Hamstring/Glute
  weightGainExerciseImg, // Saturday - Upper Body Volume
  weightGainExerciseImg, // Sunday - Rest & Feed
];

// Muscle Gain Food Images - different image for each day
// Using available images to create visual diversity each day
// Note: Currently limited to one weight gain image, but structure allows for easy addition of unique images per day
const muscleGainFoodImgs = [
  weightGainFoodImg, // Monday - High Protein Meal
  weightGainFoodImg, // Tuesday - High Protein Meal
  weightGainFoodImg, // Wednesday - High Protein Meal
  weightGainFoodImg, // Thursday - High Protein Meal
  weightGainFoodImg, // Friday - High Protein Meal
  weightGainFoodImg, // Saturday - High Protein Meal
  weightGainFoodImg, // Sunday - High Protein Meal
];

// Image assignments based on workout types
// All weight loss workouts are cardio-based, so use cardio image
// All weight gain workouts are strength-based, so use weightlifting image
// All weight loss diets use healthy salad image
// All weight gain diets use high protein meal image

export type GoalType = "weight-loss" | "weight-gain";

export interface ExerciseItem {
  name: string;
  duration: string;
  sets?: string;
  reps?: string;
}

export interface DailyPlan {
  day: string;
  exercise: {
    title: string;
    description: string;
    duration: string;
    caloriesBurned: number;
    image: string;
    focus: string[];
    exercises: ExerciseItem[];
  };
  diet: {
    breakfast: string;
    lunch: string;
    dinner: string;
    snacks: string[];
    totalCalories: number;
    macros: { p: string; c: string; f: string };
    image: string;
  };
}

export const weeklyPlans: Record<GoalType, DailyPlan[]> = {
  "weight-loss": [
    {
      day: "Monday",
      exercise: {
        title: "HIIT Cardio Blast",
        description: "High-intensity interval training to maximize fat burn.",
        duration: "45 mins",
        caloriesBurned: 450,
        image: weightLossExerciseImg, // Monday - HIIT Cardio Blast
        focus: ["Cardio", "Endurance", "Core"],
        exercises: [
          { name: "Warm-up Jog", duration: "5 minutes" },
          { name: "High Knees", duration: "30 seconds", sets: "4 sets", reps: "30 sec on, 30 sec rest" },
          { name: "Burpees", duration: "45 seconds", sets: "4 sets", reps: "45 sec on, 15 sec rest" },
          { name: "Mountain Climbers", duration: "30 seconds", sets: "4 sets", reps: "30 sec on, 30 sec rest" },
          { name: "Jump Squats", duration: "45 seconds", sets: "3 sets", reps: "45 sec on, 15 sec rest" },
          { name: "Plank Hold", duration: "60 seconds", sets: "3 sets", reps: "60 sec on, 30 sec rest" },
          { name: "Cool-down Stretch", duration: "5 minutes" },
        ],
      },
      diet: {
        breakfast: "Oatmeal with berries and almond butter",
        lunch: "Grilled chicken salad with avocado dressing",
        dinner: "Baked salmon with steamed broccoli and quinoa",
        snacks: ["Apple slices", "Greek yogurt"],
        totalCalories: 1800,
        macros: { p: "140g", c: "180g", f: "60g" },
        image: weightLossFoodImg, // Monday - Healthy Meal
      },
    },
    {
      day: "Tuesday",
      exercise: {
        title: "Tabata Core & Legs",
        description: "Focus on lower body strength with short rest intervals.",
        duration: "40 mins",
        caloriesBurned: 380,
        image: weightLossExerciseImg, // Tuesday - Tabata Core & Legs
        focus: ["Legs", "Abs", "Agility"],
        exercises: [
          { name: "Dynamic Warm-up", duration: "5 minutes" },
          { name: "Squats", duration: "20 seconds", sets: "8 rounds", reps: "20 sec on, 10 sec rest" },
          { name: "Lunges", duration: "20 seconds", sets: "8 rounds", reps: "20 sec on, 10 sec rest" },
          { name: "Leg Raises", duration: "20 seconds", sets: "8 rounds", reps: "20 sec on, 10 sec rest" },
          { name: "Russian Twists", duration: "20 seconds", sets: "8 rounds", reps: "20 sec on, 10 sec rest" },
          { name: "Wall Sit", duration: "45 seconds", sets: "3 sets", reps: "45 sec hold" },
          { name: "Stretching", duration: "5 minutes" },
        ],
      },
      diet: {
        breakfast: "Smoothie bowl (spinach, banana, protein powder)",
        lunch: "Turkey wrap with whole wheat tortilla",
        dinner: "Stir-fried tofu with mixed vegetables",
        snacks: ["Carrot sticks", "Handful of almonds"],
        totalCalories: 1750,
        macros: { p: "130g", c: "170g", f: "55g" },
        image: weightLossFoodImg, // Tuesday - Healthy Meal
      },
    },
    {
      day: "Wednesday",
      exercise: {
        title: "Active Recovery Yoga",
        description: "Low impact stretching and mobility flow.",
        duration: "60 mins",
        caloriesBurned: 200,
        image: weightLossExerciseImg, // Wednesday - Active Recovery Yoga
        focus: ["Flexibility", "Mobility", "Mindfulness"],
        exercises: [
          { name: "Breathing & Centering", duration: "5 minutes" },
          { name: "Sun Salutation A", duration: "3 minutes", sets: "5 rounds" },
          { name: "Warrior Poses", duration: "2 minutes each", sets: "3 poses each side" },
          { name: "Triangle Pose", duration: "1 minute", sets: "3 sets each side" },
          { name: "Downward Dog Flow", duration: "5 minutes" },
          { name: "Seated Forward Fold", duration: "3 minutes" },
          { name: "Savasana (Rest)", duration: "10 minutes" },
        ],
      },
      diet: {
        breakfast: "Scrambled eggs with spinach and toast",
        lunch: "Lentil soup with side salad",
        dinner: "Grilled chicken breast with zucchini noodles",
        snacks: ["Pear", "Cottage cheese"],
        totalCalories: 1600,
        macros: { p: "145g", c: "150g", f: "50g" },
        image: weightLossFoodImg, // Wednesday - Healthy Meal
      },
    },
    {
        day: "Thursday",
        exercise: {
          title: "Full Body Circuit",
          description: "Compound movements hitting every muscle group.",
          duration: "50 mins",
          caloriesBurned: 500,
        image: weightLossExerciseImg, // Thursday - Full Body Circuit
        focus: ["Strength", "Cardio", "Coordination"],
          exercises: [
            { name: "Warm-up", duration: "5 minutes" },
            { name: "Push-ups", duration: "45 seconds", sets: "3 sets", reps: "45 sec on, 15 sec rest" },
            { name: "Squat Jumps", duration: "45 seconds", sets: "3 sets", reps: "45 sec on, 15 sec rest" },
            { name: "Plank to Push-up", duration: "30 seconds", sets: "3 sets", reps: "30 sec on, 30 sec rest" },
            { name: "Jumping Lunges", duration: "45 seconds", sets: "3 sets", reps: "45 sec on, 15 sec rest" },
            { name: "Bicycle Crunches", duration: "45 seconds", sets: "3 sets", reps: "45 sec on, 15 sec rest" },
            { name: "Cool-down", duration: "5 minutes" },
          ],
        },
        diet: {
          breakfast: "Greek yogurt parfait with granola",
          lunch: "Tuna salad lettuce wraps",
          dinner: "Lean beef stir-fry with peppers",
          snacks: ["Orange", "Protein bar"],
          totalCalories: 1850,
          macros: { p: "150g", c: "175g", f: "65g" },
          image: weightLossFoodImg, // Thursday - Healthy Meal
        },
      },
      {
        day: "Friday",
        exercise: {
          title: "Sprint Intervals",
          description: "Explosive running intervals on track or treadmill.",
          duration: "30 mins",
          caloriesBurned: 400,
        image: weightLossExerciseImg, // Friday - Sprint Intervals
        focus: ["Speed", "Power", "Legs"],
          exercises: [
            { name: "Light Jog Warm-up", duration: "5 minutes" },
            { name: "Sprint", duration: "30 seconds", sets: "8 sets", reps: "30 sec sprint, 90 sec walk" },
            { name: "Recovery Walk", duration: "90 seconds", sets: "Between each sprint" },
            { name: "Cool-down Walk", duration: "5 minutes" },
            { name: "Stretching", duration: "5 minutes" },
          ],
        },
        diet: {
          breakfast: "Egg white omelet with mushrooms",
          lunch: "Quinoa bowl with black beans and corn",
          dinner: "White fish with roasted asparagus",
          snacks: ["Celery with peanut butter", "Berries"],
          totalCalories: 1700,
          macros: { p: "140g", c: "160g", f: "55g" },
          image: weightLossFoodImg, // Friday - Healthy Meal
        },
      },
      {
        day: "Saturday",
        exercise: {
          title: "Long Distance Run/Hike",
          description: "Steady state cardio outdoors.",
          duration: "90 mins",
          caloriesBurned: 600,
        image: weightLossExerciseImg, // Saturday - Long Distance Run/Hike
        focus: ["Endurance", "Mental Health"],
          exercises: [
            { name: "Warm-up Walk", duration: "5 minutes" },
            { name: "Steady Pace Run/Hike", duration: "75 minutes", sets: "Maintain consistent pace" },
            { name: "Cool-down Walk", duration: "5 minutes" },
            { name: "Full Body Stretch", duration: "5 minutes" },
          ],
        },
        diet: {
          breakfast: "Protein pancakes with sugar-free syrup",
          lunch: "Chicken caesar salad (light dressing)",
          dinner: "Shrimp tacos with cabbage slaw",
          snacks: ["Protein shake", "Banana"],
          totalCalories: 1900,
          macros: { p: "150g", c: "200g", f: "60g" },
          image: weightLossFoodImg, // Saturday - Healthy Meal
        },
      },
      {
        day: "Sunday",
        exercise: {
          title: "Rest & Mobility",
          description: "Light foam rolling and stretching.",
          duration: "20 mins",
          caloriesBurned: 100,
        image: weightLossExerciseImg, // Sunday - Rest & Mobility
        focus: ["Recovery"],
          exercises: [
            { name: "Neck & Shoulder Rolls", duration: "2 minutes" },
            { name: "Foam Roll Legs", duration: "5 minutes" },
            { name: "Hip Flexor Stretch", duration: "2 minutes each side" },
            { name: "Hamstring Stretch", duration: "2 minutes each side" },
            { name: "Full Body Stretch", duration: "5 minutes" },
          ],
        },
        diet: {
          breakfast: "Avocado toast with poached egg",
          lunch: "Vegetable soup",
          dinner: "Roast chicken with sweet potato",
          snacks: ["Dark chocolate (small piece)", "Nuts"],
          totalCalories: 1800,
          macros: { p: "130g", c: "180g", f: "60g" },
          image: weightLossFoodImg, // Sunday - Healthy Meal
        },
      },
  ],
  "weight-gain": [
    {
      day: "Monday",
      exercise: {
        title: "Heavy Chest & Triceps",
        description: "Compound lifts focusing on upper body pushing strength.",
        duration: "75 mins",
        caloriesBurned: 350,
        image: muscleGainExerciseImgs[0], // Monday - Heavy Chest & Triceps (Day 1)
        focus: ["Chest", "Triceps", "Strength"],
        exercises: [
          { name: "Warm-up", duration: "10 minutes" },
          { name: "Bench Press", duration: "20 minutes", sets: "4 sets", reps: "6-8 reps" },
          { name: "Incline Dumbbell Press", duration: "15 minutes", sets: "3 sets", reps: "8-10 reps" },
          { name: "Dips", duration: "10 minutes", sets: "3 sets", reps: "8-12 reps" },
          { name: "Tricep Cable Extensions", duration: "10 minutes", sets: "3 sets", reps: "10-12 reps" },
          { name: "Chest Flyes", duration: "10 minutes", sets: "3 sets", reps: "10-12 reps" },
        ],
      },
      diet: {
        breakfast: "3 Whole eggs, 2 slices toast, avocado",
        lunch: "8oz Steak with large potato and green beans",
        dinner: "Pasta bolognese with lean beef",
        snacks: ["Protein shake with milk", "Bagel with cream cheese"],
        totalCalories: 3200,
        macros: { p: "220g", c: "350g", f: "90g" },
        image: muscleGainFoodImgs[0], // Monday - High Protein Meal (Day 1)
      },
    },
    {
      day: "Tuesday",
      exercise: {
        title: "Back & Biceps Power",
        description: "Deadlifts and rows for building a thick back.",
        duration: "70 mins",
        caloriesBurned: 380,
        image: muscleGainExerciseImgs[1], // Tuesday - Back & Biceps Power (Day 2)
        focus: ["Back", "Biceps", "Grip"],
        exercises: [
          { name: "Warm-up", duration: "10 minutes" },
          { name: "Deadlifts", duration: "20 minutes", sets: "4 sets", reps: "5-6 reps" },
          { name: "Barbell Rows", duration: "15 minutes", sets: "4 sets", reps: "8-10 reps" },
          { name: "Pull-ups", duration: "10 minutes", sets: "3 sets", reps: "8-12 reps" },
          { name: "Barbell Curls", duration: "10 minutes", sets: "3 sets", reps: "8-10 reps" },
          { name: "Hammer Curls", duration: "5 minutes", sets: "3 sets", reps: "10-12 reps" },
        ],
      },
      diet: {
        breakfast: "Large bowl of oatmeal with protein powder & peanut butter",
        lunch: "Chicken breast with rice and olive oil",
        dinner: "Salmon fillet with quinoa and avocado",
        snacks: ["Greek yogurt with honey", "Trail mix"],
        totalCalories: 3100,
        macros: { p: "210g", c: "340g", f: "95g" },
        image: muscleGainFoodImgs[1], // Tuesday - High Protein Meal (Day 2)
      },
    },
    {
      day: "Wednesday",
      exercise: {
        title: "Leg Day - Quad Focus",
        description: "Squats and lunges for lower body mass.",
        duration: "80 mins",
        caloriesBurned: 450,
        image: muscleGainExerciseImgs[2], // Wednesday - Leg Day Quad Focus (Day 3)
        focus: ["Quads", "Calves", "Core"],
        exercises: [
          { name: "Warm-up", duration: "10 minutes" },
          { name: "Barbell Squats", duration: "25 minutes", sets: "5 sets", reps: "6-8 reps" },
          { name: "Leg Press", duration: "15 minutes", sets: "4 sets", reps: "10-12 reps" },
          { name: "Walking Lunges", duration: "15 minutes", sets: "3 sets", reps: "12 reps each leg" },
          { name: "Leg Extensions", duration: "10 minutes", sets: "3 sets", reps: "12-15 reps" },
          { name: "Calf Raises", duration: "5 minutes", sets: "4 sets", reps: "15-20 reps" },
        ],
      },
      diet: {
        breakfast: "Breakfast burrito with eggs, beans, cheese",
        lunch: "Turkey meatballs with marinara and pasta",
        dinner: "Burger (lean beef) with baked fries",
        snacks: ["Protein bar", "Banana with peanut butter"],
        totalCalories: 3300,
        macros: { p: "200g", c: "380g", f: "100g" },
        image: muscleGainFoodImgs[2], // Wednesday - High Protein Meal (Day 3)
      },
    },
    {
        day: "Thursday",
        exercise: {
          title: "Shoulders & Abs",
          description: "Overhead pressing for broad shoulders.",
          duration: "60 mins",
          caloriesBurned: 300,
        image: muscleGainExerciseImgs[3], // Thursday - Shoulders & Abs (Day 4)
        focus: ["Delts", "Traps", "Core"],
          exercises: [
            { name: "Warm-up", duration: "10 minutes" },
            { name: "Overhead Press", duration: "15 minutes", sets: "4 sets", reps: "6-8 reps" },
            { name: "Lateral Raises", duration: "10 minutes", sets: "3 sets", reps: "12-15 reps" },
            { name: "Front Raises", duration: "10 minutes", sets: "3 sets", reps: "10-12 reps" },
            { name: "Ab Crunches", duration: "10 minutes", sets: "3 sets", reps: "15-20 reps" },
            { name: "Plank", duration: "5 minutes", sets: "3 sets", reps: "60 sec hold" },
          ],
        },
        diet: {
          breakfast: "French toast with protein batter",
          lunch: "Chicken thighs with roasted sweet potato",
          dinner: "Beef stir-fry with udon noodles",
          snacks: ["Cottage cheese with fruit", "Pretzels"],
          totalCalories: 3000,
          macros: { p: "200g", c: "320g", f: "90g" },
          image: muscleGainFoodImgs[3], // Thursday - High Protein Meal (Day 4)
        },
      },
      {
        day: "Friday",
        exercise: {
          title: "Leg Day - Hamstring/Glute",
          description: "RDLs and hip thrusts.",
          duration: "70 mins",
          caloriesBurned: 400,
        image: muscleGainExerciseImgs[4], // Friday - Leg Day Hamstring/Glute (Day 5)
        focus: ["Hamstrings", "Glutes"],
          exercises: [
            { name: "Warm-up", duration: "10 minutes" },
            { name: "Romanian Deadlifts", duration: "20 minutes", sets: "4 sets", reps: "8-10 reps" },
            { name: "Hip Thrusts", duration: "15 minutes", sets: "4 sets", reps: "10-12 reps" },
            { name: "Leg Curls", duration: "10 minutes", sets: "3 sets", reps: "12-15 reps" },
            { name: "Glute Bridges", duration: "10 minutes", sets: "3 sets", reps: "15 reps" },
            { name: "Stretching", duration: "5 minutes" },
          ],
        },
        diet: {
          breakfast: "Omelet with cheese and toast",
          lunch: "Tuna pasta bake",
          dinner: "Pizza (homemade with high protein base)",
          snacks: ["Protein shake", "Ice cream (small scoop)"],
          totalCalories: 3400,
          macros: { p: "210g", c: "360g", f: "110g" },
          image: muscleGainFoodImgs[4], // Friday - High Protein Meal (Day 5)
        },
      },
      {
        day: "Saturday",
        exercise: {
          title: "Upper Body Volume",
          description: "Pump work for chest, back, and arms.",
          duration: "60 mins",
          caloriesBurned: 350,
        image: muscleGainExerciseImgs[5], // Saturday - Upper Body Volume (Day 6)
        focus: ["Hypertrophy", "Upper Body"],
          exercises: [
            { name: "Warm-up", duration: "10 minutes" },
            { name: "Dumbbell Bench Press", duration: "15 minutes", sets: "4 sets", reps: "10-12 reps" },
            { name: "Cable Rows", duration: "12 minutes", sets: "3 sets", reps: "12-15 reps" },
            { name: "Bicep Curls", duration: "10 minutes", sets: "3 sets", reps: "12-15 reps" },
            { name: "Tricep Pushdowns", duration: "10 minutes", sets: "3 sets", reps: "12-15 reps" },
            { name: "Cool-down", duration: "3 minutes" },
          ],
        },
        diet: {
          breakfast: "Pancakes with eggs and bacon",
          lunch: "Sub sandwich with double meat",
          dinner: "Curry chicken with rice and naan",
          snacks: ["Protein smoothie", "Nuts"],
          totalCalories: 3500,
          macros: { p: "200g", c: "400g", f: "100g" },
          image: muscleGainFoodImgs[5], // Saturday - High Protein Meal (Day 6)
        },
      },
      {
        day: "Sunday",
        exercise: {
          title: "Rest & Feed",
          description: "Complete rest to allow muscle growth.",
          duration: "0 mins",
          caloriesBurned: 0,
        image: muscleGainExerciseImgs[6], // Sunday - Rest & Feed (Day 7)
        focus: ["Growth", "Sleep"],
          exercises: [
            { name: "Complete Rest Day", duration: "Full day" },
            { name: "Light Walking (Optional)", duration: "20-30 minutes" },
            { name: "Stretching (Optional)", duration: "10 minutes" },
          ],
        },
        diet: {
          breakfast: "Bagel with smoked salmon and cream cheese",
          lunch: "Roast beef dinner with all trimmings",
          dinner: "Leftover roast or sandwich",
          snacks: ["Cheesecake", "Milk"],
          totalCalories: 3000,
          macros: { p: "180g", c: "300g", f: "100g" },
          image: muscleGainFoodImgs[6], // Sunday - High Protein Meal (Day 7)
        },
      },
  ],
};
